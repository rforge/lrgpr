

# Test exclusion


scp baal:"~/data/workspace/repos/lrgpr_0.0.4.tar.gz" ~/
R CMD INSTALL ~/lrgpr_0.0.4.tar.gz


q()
R

suppressPackageStartupMessages(library(lrgpr))

X <- attach.big.matrix("IBD15_PCA.binary_descr")

FAM = read.fam("IBD15_PCA.fam")

y = FAM$phenotype
sex = FAM$sex


i = 30000 + 1
pValues = glmApply( y ~ sex + SNP, features=X, cincl=c(i))$pValues

pValues[i]

coef(summary(lm( y ~ sex + X[,i])))[4,4]

# NumericMatrix 
glmApply( y ~ sex + SNP, features=X[,i])$pValues

# NumericMatrix with cincl
glmApply( y ~ sex + SNP, features=X, cincl=i)$pValues[i]




p1 = glmApply( y ~ sex + SNP, features=X)$pValues


# include
i = sample(1:ncol(X), 1234)

p2 = glmApply( y ~ sex + SNP, features=X, cincl=i)$pValues
 
cor(p1[i], p2[i], use="pairwise.complete.obs")

plot(p1[i], p2[i])


# exclude
i = sample(1:ncol(X), 1234)

p2 = glmApply( y ~ sex + SNP, features=X, cexcl=i)$pValues


cor(p1[-i], p2[-i], use="pairwise.complete.obs")

plot(p1[-i], p2[-i])


# lrgprApply
#############



q()
R

suppressPackageStartupMessages(library(lrgpr))

X <- attach.big.matrix("IBD15_PCA.binary_descr")

FAM = read.fam("IBD15_PCA.fam")

y = FAM$phenotype
sex = FAM$sex

j = round(seq(1, ncol(X), length.out=100))

dcmp = svd(scale(X[,j]))

# MAP = readRDS("MAP.RDS")
# saveRDS(MAP[1:ncol(X),], file="MAP_j.RDS")


MAP = readRDS("MAP_j.RDS")

#pSMA = glmApply2( y ~ sex + SNP, features=X)$pValues


p = lrgprApply( y ~ sex + SNP, features=X, decomp=dcmp, map=MAP[,c(1,3)], distance = 1000.02, dcmp_features=j, cincl=j[1], reEstimateDelta=T)


p[1]

p = lrgprApply( y ~ sex + SNP, features=X, decomp=dcmp, map=MAP[,c(1,3)], distance = 1000.02, dcmp_features=j[1:10], cincl=1, reEstimateDelta=T)

p[1]

fit = lrgpr(y ~ sex + X[,j[1]], decomp=dcmp, W_til=X[,j[1:10]])
coef(summary(fit))



QQ_plot(cbind(pSMA, p))







# WTCCC
#######

cd /data/test_space/WTCCC/CD_lrgpr

q()
R

suppressPackageStartupMessages(library(lrgpr))
library(glmnet)

X <- attach.big.matrix("../CD.binary_descr")

FAM = read.fam("../CD.fam")

y = FAM$phenotype
sex = FAM$sex
nPC = 5

# SVD
j = round(seq(1, ncol(X), length.out=20000))
j = j[which(apply(set_missing_to_mean(X[,j]), 2, var) != 0)]

dcmp = svd(scale(set_missing_to_mean(X[,j])), nu = 100, nv=1)

saveRDS(dcmp, file="dcmp.RDS")

# SMA
pSMA = glmApply2( y ~ sex + SNP + dcmp$u[,1:nPC], features=X)$pValues

saveRDS(pSMA, file="pSMA.RDS")

# LASSO
j = which(pSMA < 1e-2)
penalty.factor = c(rep(0, nPC), rep(1, length(j)))

lfit = glmnet( cbind(dcmp$u[,1:nPC], set_missing_to_mean(X[,j])), y, dfmax=length(j)/2, nlambda=length(j)/2, penalty.factor=penalty.factor)

entry = apply(lfit$beta, 1, function(a){ max(which(a == 0))})

ord = j[order(entry[-c(1:nPC)], decreasing=FALSE)]

saveRDS(lfit, file="lfit.RDS")

# Restart
lfit = readRDS("lfit.RDS")
pSMA = readRDS("pSMA.RDS")
dcmp = readRDS("dcmp.RDS")

j = which(pSMA < 1e-2)

entry = apply(lfit$beta, 1, function(a){ max(which(a == 0))})

ord = j[order(entry[-c(1:nPC)], decreasing=FALSE)]

# Learn rank
rank = c(seq(1, 10), seq(20, 100, by = 10), seq(200, 1000, by = 100), seq(1000, 5000, by = 1000))

cn = colnames(X)
j = which( cn %in% names(entry))
cn_j = cn[j]

# get order
idx = c()
for(value in sort(unique(entry)) ){
	if( length(which(entry == value)) > 0){
		idx = append(idx, which( cn_j %in% names(entry)[which(entry == value)] ) )
	}
}

ord2 = j[idx]

saveRDS(ord2, "ord2.RDS")

critfit2 = criterion.lrgpr( y ~ sex + dcmp$u[,1:nPC], features=X, order=ord2, rank=rank)

plot(critfit2)

saveRDS(critfit2, file="critfit2.RDS")


dcmp_kin = svd(scale(set_missing_to_mean(X[,ord2[1:critfit2$best$GCV]])), nv=1)

saveRDS(dcmp_kin, "dcmp_kin.RDS")

# lrgprApply
#############

q()
R

suppressPackageStartupMessages(library(lrgpr))
library(glmnet)

X <- attach.big.matrix("../CD.binary_descr")

FAM = read.fam("../CD.fam")

y = FAM$phenotype
sex = FAM$sex
nPC = 5
MAP = read.table("../CD.map", stringsAsFactors=F)
dcmp = readRDS("dcmp.RDS")
ord2 = readRDS("ord2.RDS")
critfit2 = readRDS("critfit2.RDS")
dcmp_kin = readRDS("dcmp_kin.RDS")

p = lrgprApply( y ~ sex + dcmp$u[,1:nPC] + SNP, features=X, decomp=dcmp_kin, map=MAP[,c(1,4)], distance = 5e6, dcmp_features=ord2[1:critfit2$best$GCV], nthreads=4)


# lrgprSKAT
###########

q()
R

suppressPackageStartupMessages(library(lrgprSKAT))

geneAnnotations = get_genes()

X <- attach.big.matrix("../CD.binary_descr")

FAM = read.fam("../CD.fam")

y = FAM$phenotype
sex = FAM$sex
nPC = 5
MAP = read.table("../CD.map", stringsAsFactors=F)
dcmp = readRDS("dcmp.RDS")
ord2 = readRDS("ord2.RDS")
critfit2 = readRDS("critfit2.RDS")
dcmp_kin = readRDS("dcmp_kin.RDS")



fitSKAT = SKAT_Null_Model( y ~ sex + dcmp$u[,1:nPC] )

library(doMC)
library(foreach)
registerDoMC(4)

pSKAT = SKATpApply( fitSKAT, geneAnnotations[1:30,], X, MAP, 50000, is_dosage=TRUE, kernel="linear")



library(doMC)
library(foreach)
registerDoMC(4)

library(bigmemoryExtras)
A = BigMatrix(x=X, backingfile="dasu_IBD15_1KG_combined.dosage.binary")

pSKAT = SKATpApply( fitSKAT, geneAnnotations[1:10,], A, MAP, 50000, is_dosage=TRUE, kernel="linear")



fitSKAT = SKAT_Null_Model( y ~ sex + dcmp$u[,1:nPC] )

pSKAT = SKATApply( fitSKAT, geneAnnotations, X, MAP, 50000, is_dosage=TRUE, kernel="linear")

saveRDS(pSKAT, "pSKAT.RDS")



fit = lrgpr( y ~ sex + dcmp$u[,1:nPC], decomp=dcmp_kin)

plrgpr = SKATApply( fit, geneAnnotations, X, MAP, 50000, is_dosage=TRUE, kernel="linear", dcmp_features=ord2[1:critfit2$best$GCV])



gene = "IL23R"
up = 50000
down = up
dcmp_features=ord2[1:critfit2$best$GCV]
kernel = "linear";
 weights=NULL; method="davies";
  r.corr=0; is_dosage=TRUE; is_check_genotype=FALSE





lrgprGeneTest( fitSKAT, geneAnnotations, X, "ATG16L1", MAP, 50000, is_dosage=TRUE, kernel="linear")



lrgprGeneTest( fitSKAT, geneAnnotations, X, "IL23R", MAP, 50000, is_dosage=TRUE, kernel="linear")

lrgprGeneTest( fitSKAT, geneAnnotations, X, "CASP3", MAP, 50000, is_dosage=TRUE, kernel="linear")


lrgprGeneTest( fit, geneAnnotations, X, "IL23R", MAP, 50000, is_dosage=TRUE, kernel="linear", dcmp_features=ord2[1:critfit2$best$GCV])



cor(fitSKAT$res, predict(fit))^2
cor(fitSKAT$res, predict(reFit))^2
cor(predict(fit), predict(reFit))^2



reFit = lrgpr( fit$y ~ fit$x -1, decomp=list(vectors=fit$eigenVectors, values=fit$eigenValues), W_til=scale(set_missing_to_mean(X[,dcmp_features[1:60]])))



d = svd(scale(set_missing_to_mean(X[,dcmp_features])))

reFit = lrgpr( fit$y ~ fit$x -1, decomp=d, W_til=scale(set_missing_to_mean(X[,dcmp_features[1:60]])))

a = lrgpr( fit$y ~ fit$x -1, decomp=svd(scale(set_missing_to_mean(X[,dcmp_features[-c(1:60)]]))))

cbind(head(predict(reFit)), head(predict(a)))


cbind(head(reFit$fitted.values), head(a$fitted.values))




# Build in warning about W_til


cor(predict(fit), predict(reFit))^2
cor(predict(fit), predict(a))^2
cor(predict(reFit), predict(a))^2



fitSKAT = SKAT_Null_Model( y ~ sex + dcmp$u[,1:nPC] )

reFit = lrgpr( fit$y ~ fit$x -1, decomp=svd(scale(set_missing_to_mean(X[,dcmp_features[-ii]]))))


reFit = lrgpr( fit$y ~ fit$x -1, decomp=svd(scale(set_missing_to_mean(X[,1]))))


cor(fitSKAT$res, residuals(fit))^2
cor(fitSKAT$res, residuals(reFit))^2
cor(residuals(fit), residuals(reFit))^2


summary(lm( set_missing_to_mean(X[,1633]) ~ set_missing_to_mean(X[,8023])))




reFit = lrgpr( fit$y ~ fit$x -1, decomp=svd(scale(set_missing_to_mean(X[,dcmp_features[-ii]]))))

SKAT(Z, lrgprToSKAT(reFit), kernel=kernel, weights=weights, method=method, r.corr=r.corr, is_dosage=is_dosage, is_check_genotype=FALSE)$p.value



reFit = lrgpr( fit$y ~ fit$x -1, decomp=svd(scale(set_missing_to_mean(X[,dcmp_features[1]]))))

SKAT(Z, lrgprToSKAT(reFit), kernel=kernel, weights=weights, method=method, r.corr=r.corr, is_dosage=is_dosage, is_check_genotype=FALSE)$p.value



s = svd(scale(set_missing_to_mean(X[,dcmp_features])))

plot(s$d)


s = svd(scale(set_missing_to_mean(X[,sample(1:ncol(X), length(dcmp_features))])))

plot(s$d)





p = lrgprApply( y ~ sex + dcmp$u[,1:nPC] + SNP, features=X, decomp=dcmp_kin, W_til=X[,1], nthreads=4)







pSMA = glmApply2( y ~ sex + dcmp$u[,1:nPC] + SNP, features=X)


R

suppressPackageStartupMessages(library(lrgpr))
library(glmnet)

X <- attach.big.matrix("../CD.binary_descr")

FAM = read.fam("../CD.fam")

y = FAM$phenotype
sex = FAM$sex
nPC = 20
dcmp = readRDS("dcmp.RDS")
dcmp_kin = readRDS("dcmp_kin.RDS")

fit = lrgpr( y ~ sex + dcmp$u[,1:nPC], decomp=dcmp_kin, nthreads=4)




# Epistasis
###########


s1 = lrgprGeneScore( fitSKAT, geneAnnotations, X, "IL23R", MAP, 50000)
s2 = lrgprGeneScore( fitSKAT, geneAnnotations, X, "NOD2", MAP, 50000)
s3 = lrgprGeneScore( fitSKAT, geneAnnotations, X, "IL23A", MAP, 50000)
s4 = lrgprGeneScore( fitSKAT, geneAnnotations, X, "ATG16L1", MAP, 50000)
s5 = lrgprGeneScore( fitSKAT, geneAnnotations, X, "CASP3", MAP, 50000)


coef(summary(lm( y ~ sex + s1*s2)))

coef(summary(lm( y ~ s1*sex)))

coef(summary(lm( y ~ sex + s1*s3)))

coef(summary(lm( y ~ sex + s2*s3)))


coef(summary(lm( y ~ sex + s3)))

cor.test(s1, s2)$p.value
cor.test(s1, s3)$p.value
cor.test(s2, s3)$p.value
cor.test(s1, s4)$p.value

M = cbind(s1, s2, s3, s4, s5)


C = cor(M)


cor.p.value = function(y, s1, s2){

	k = which(y==1)

	r1 = cor(s1[k], s2[k])
	r2 = cor(s1[-k], s2[-k])

	n = length(k)
	se1 = sqrt((1 - r1^2)/(n-2))

	n = length(y) - length(k)
	se2 = sqrt((1 - r2^2)/(n-2))

	stat = (r1 - r2)^2 / (se1^2 + se2^2)

	pchisq(stat, 1, lower.tail=FALSE)
}

epistasisTestCor = function(y, M){
	res = matrix(NA, ncol(M), ncol(M))

	for(i in 1:ncol(M)){
		for(j in (i+1):ncol(M)){
			if( j > ncol(M)) break
			res[i,j]  = cor.p.value(y, M[,i], M[,j])
		}
	}	
	return(res)
}


epistasisTestCor2 = function(y, M){
	res = matrix(NA, ncol(M), ncol(M))

	for(i in 1:ncol(M)){
		for(j in (i+1):ncol(M)){
			if( j > ncol(M)) break
			res[i,j]  = cor.test(M[,i], M[,j])$p.value
		}
	}	
	return(res)
}

epistasisTestRegress = function(y, M){
	res = matrix(NA, ncol(M), ncol(M))

	for(i in 1:ncol(M)){
		for(j in (i+1):ncol(M)){
			if( j > ncol(M)) break
			res[i,j] = coef(summary(lm(y ~ M[,i]*M[,j])))[4,4]
		}
	}	
	return(res)
}


M = matrix(rnorm(length(y)*200), length(y), 200)

epiCor = epistasisTestCor( y, M)
epiReg = epistasisTestRegress( y, M)


QQ_plot(as.vector(epiCor))

QQ_plot(cbind(as.vector(epiCor), as.vector(epiReg)))


epiCor2 = epistasisTestCor2( y, M)

QQ_plot(as.vector(epiCor2))

a1 = s1 - mean(s1)
a2 = s2 - mean(s2)

d = (a1 - a2)^2



plot(s1, s4, col=ifelse(y==1, "red", "blue" ))

k = which(y==2)

fit = lm( s1[k] ~ s4[k] )

x = seq(min(s1), max(s1), length.out=1000)

lines(x, coef(fit)[1] + coef(fit)[2]*x)

fit = lm( s1[-k] ~ s4[-k] )
lines(x, coef(fit)[1] + coef(fit)[2]*x)



# ~/Downloads/R-3.0.1_debug/bin/R


# set print thread-events off

q()
R

suppressPackageStartupMessages(library(lrgpr))
library(glmnet)

X <- attach.big.matrix("../CD.binary_descr")

FAM = read.fam("../CD.fam")

y = FAM$phenotype
sex = FAM$sex
nPC = 5


# Restart
lfit = readRDS("lfit.RDS")
pSMA = readRDS("pSMA.RDS")
dcmp = readRDS("dcmp.RDS")

j = which(pSMA < 1e-2)

entry = apply(lfit$beta, 1, function(a){ max(which(a == 0))})

ord = j[order(entry[-c(1:nPC)], decreasing=FALSE)]




# Learn rank
rank = c(seq(1, 10), seq(20, 100, by = 10), seq(200, 1000, by = 100), seq(1000, 5000, by = 1000))

cn = colnames(X)
j = which( cn %in% names(entry))
cn_j = cn[j]

# get order
idx = c()
for(value in sort(unique(entry)) ){
	if( length(which(entry == value)) > 0){
		idx = append(idx, which( cn_j %in% names(entry)[which(entry == value)] ) )
	}
}

ord2 = j[idx]

critfit2 = criterion.lrgpr( y ~ sex + dcmp$u[,1:nPC], features=X, order=ord2, rank=c(100, 200, 300,400))



#critfit2 = criterion.lrgpr( y ~ sex + dcmp$u[,1:nPC], features=X, order=ord2, rank=rank)


formula = y ~ sex + dcmp$u[,1:nPC]
features=X; order=ord2; rank=c(100, 200, 300,400)


dcmp2 = svd( scale(set_missing_to_mean(features[,order[1:300]])), nv=1 )
fit = lrgpr( formula, dcmp2)

fit = lrgpr( formula, dcmp2)

fit = lrgpr( formula, dcmp2)

Xu = as.matrix(read.table("Xu.mat"))
inv_s_delta_Xu = as.matrix(read.table("inv_s_delta_Xu.mat"))

crossprod(Xu, inv_s_delta_Xu)









./configure CFLAGS="-O2 -fopenmp -march=native -g2" FCFLAGS="-O2 -fopenmp -march=native -g2" FFLAGS="-O2 -fopenmp -march=native -g" CXXFLAGS="-O2 -fopenmp -march=native -g2" --enable-R-shlib --enable-threads=posix -with-blas="-L/opt/acml5.3.1/ifort64_fma4/lib/ -lacml" --with-lapack --with-tcltk


./configure CFLAGS="-O2 -fopenmp -march=native -g2" FCFLAGS="-O2 -fopenmp -march=native -g2" FFLAGS="-O2 -fopenmp -march=native -g" CXXFLAGS="-O2 -fopenmp -march=native -g2" --enable-R-shlib --enable-threads=posix -with-blas="-L/opt/acml5.3.1/ifort64_mp//lib/ -lacml_mp" --with-lapack --with-tcltk



library(lrgprSKAT)
geneAnnotations = get_genes()
pSKAT = readRDS("pSKAT.RDS")


