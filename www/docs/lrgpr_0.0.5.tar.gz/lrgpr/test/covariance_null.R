
# GEH 
# March 4, 2014

library(compiler)
library(foreach)
library(doMC)
library(lrgpr)

registerDoMC(8)

# Empirical p-value using permutations
perm_p_value = cmpfun(function(y, s1, s2, k){

	n = length(y)

	# regression
	fit1 = lm(s1 ~ y)
	fit2 = lm(s2 ~ y)

	# simulate new values with same properties as s1, s2 using regression parameters
	# draw the covariance term from he null distribution
	null_values = foreach(i=1:n_reps, .combine=c) %do% {
		
		sigma1 = summary(fit1)$sigma
		sigma2 = summary(fit2)$sigma

		a1 = coef(fit1)[1] + coef(fit1)[2] * y + rnorm(n, 0, sigma1)
		a2 = coef(fit2)[1] + coef(fit2)[2] * y + rnorm(n, 0, sigma2)

		cov(a1[1:k], a2[1:k])
	}

	# compute the actual covariance
	stat = cov(s1[1:k], s2[1:k])

	# compare to null in a one-sided test
	sum(stat >= null_values) / length(null_values)
})


n_reps = 1000
n = 100
k = 50

pValues = c()

pValues = foreach(i=1:200, .combine=c) %dopar% {
	y = rnorm(n)

	# lrgpr predictors
	s1  = runif(1, -.1,.1)*y + rnorm(n, 0, 2)
	s2  = runif(1, -.1,.1)*y + rnorm(n, 0, 2)

	perm_p_value(y, s1, s2, k) 

	coef(summary(lm( scale(s1[1:k]) ~ scale(s2[1:k])-1)))


}

QQ_plot(pValues)










