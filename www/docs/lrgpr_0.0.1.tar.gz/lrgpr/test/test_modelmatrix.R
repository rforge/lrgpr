mm = function (object, data = environment(object), contrasts.arg = NULL, 
    xlev = NULL, ...){
   
 t <- if(missing(data)){
	terms(object)
	}else{ 
	terms(object, data = data)
	}
    if(is.null(attr(data, "terms"))){
        data <- model.frame(object, data, xlev = xlev)
    }else{
        reorder <- match(sapply(attr(t, "variables"), deparse, 
            width.cutoff = 500)[-1L], names(data))
        if(any(is.na(reorder))){
            stop("model frame and formula mismatch in model.matrix()")
	}
        if(!identical(reorder, seq_len(ncol(data)))){
            data <- data[, reorder, drop = FALSE]
	}
    }


    int <- attr(t, "response")
    if(length(data)){
        contr.funs <- as.character(getOption("contrasts"))
        namD <- names(data)
        for(i in namD){ 
		if(is.character(data[[i]])){
           		 data[[i]] <- factor(data[[i]])
		}
	}
        isF <- vapply(data, function(x) is.factor(x) || is.logical(x),NA)
        isF[int] <- FALSE
        isOF <- vapply(data, is.ordered, NA)
        for(nn in namD[isF]){ 
		if(is.null(attr(data[[nn]], "contrasts"))){
	            contrasts(data[[nn]]) <- contr.funs[1 + isOF[nn]]
		}
	}
        if(!is.null(contrasts.arg) && is.list(contrasts.arg)){
            if(is.null(namC <- names(contrasts.arg))){ 
                stop("invalid 'contrasts.arg' argument")
		}
            for(nn in namC){
                if(is.na(ni <- match(nn, namD))){
                  warning(gettextf("variable '%s' is absent, its contrast will be ignored", 
                    nn), domain = NA)
               }else{
                  ca <- contrasts.arg[[nn]]
                  if( is.matrix(ca)){
                    contrasts(data[[ni]], ncol(ca)) <- ca
                  }else{
			 contrasts(data[[ni]]) <- contrasts.arg[[nn]]
			}
                }
            }
        }
    }else{
        isF <- FALSE
        data <- data.frame(x = rep(0, nrow(data)))
    }

    return( list(t=t, data=data) )
}


dyn.load("/home/likewise-open/CB/gh258/common/workspace/RCppGSL/src/lrgpr/src/lrgpr.so")


y = rnorm(1000)
sex = rnorm(1000)

res = mm( y ~ sex )

.External( "modelmatrix2", res$t, res$data, environment())



system.time( replicate( 10000, model.matrix(y ~ sex) ) )


system.time( replicate( 10000, model.matrix.default(y ~ sex) ) )


suppressWarnings(system.time( replicate( 10000, .External( "modelmatrix2", res$t, res$data, environment()) ) ))















