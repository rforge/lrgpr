

q()
R

# Conduct full rank analysis like EMMA/EMMAX/GEMMA 
##################################################

# load package
library(lrgpr)

# load genotypes from plink TPED format
X = read.tped( paste( .libPaths(), "/lrgpr/data/test.tped", sep='') )$X

# load phenotype from plink TFAM format
fam = read.tfam( paste( .libPaths(), "/lrgpr/data/test.tfam", sep='') )

# load genetic relationship matrix
K = as.matrix(read.table( paste( .libPaths(), "/lrgpr/data/K.txt", sep='') ))

# Compute principal components of genetic relationship matrix
decomp = eigen(K, symmetric=TRUE)

# Fit model
fit = lrgpr( fam$phenotype ~ fam$sex + X[,1], decomp)

# View model fit in standard R format
fit

# View model summary in standard R format
summary(fit)

# get p-values for each covariate
fit$p.values

# Visualize fit of the model like for 'lm' using standard regression diagnostics
par(mfrow=c(2,2))
plot(fit)

# Test interaction term
#######################

# Specify sex x marker interaction using standard R syntax
fit = lrgpr( fam$phenotype ~ fam$sex*X[,1], decomp)

# View model summary
summary(fit)

# Perform composite hypothesis test
###################################

# Specify marker x marker interaction using standard R syntax
fit = lrgpr( fam$phenotype ~ X[,1]*X[,2], decomp)

# Composite test of two markers + interaction
wald(fit, terms=c(2,3,4))

# Perform efficient genome-wide analysis
########################################

# Estimate delta from the null model with no markers 
# Reusing this delta-value for each test dramatically increases speed
fitnull = lrgpr( fam$phenotype ~ fam$sex, decomp)

# Process 10 markers at a time
# This should be set to a much larger value for large datasets.
batch_size = 50
 
# Start with the 0th marker
current_line = 1
 
pValues = c()

while(1){

	# Read in number of markers equal to batch_size
	# Set missing genotype values to the mean for that marker
	X = read.tped( paste( .libPaths(), "/lrgpr/data/test.tped", sep=''), missing='mean', current_line, batch_size, quiet=TRUE)

	# If no more markers are read, then break
	if( ncol(X) == 0) break		

	# Run lrgpr on this set of markers
	# Use a special syntax to process a large matrix of markers in one function call
	#	The formula contails X[,j] as a placeholder for the set of markers
	#	Using loop="X[,j]" specifies this matrix as a place holder and markers 1:ncol(X) 
	#	will be evaluated
	# Use the value of delta from the null model above by
	# 	specifying delta=fitnull$delta
	#	Set reEstimateDelta = TRUE to re-estimate delta for each marker
	# Set the number of threads so that multiple markers can be processed in parallel
	# 	Note that this will be ignored for small datasets
	pValues_local = lrgpr_batch( fam$phenotype ~ fam$sex:X[,j], loop="X[,j]", decomp, terms=c(2,3), delta=fitnull$delta, nthreads=4)

	# Save p-values from this set
	pValues = append( pValues, pValues_local )

	# Increment the current_line by batch_size to read next set of markers
	current_line = current_line + batch_size
}

# Marker x Marker interactions
##############################

# read genotype data
X = read.tped( paste( .libPaths(), "/lrgpr/data/test.tped", sep=''), missing='mean', quiet=TRUE)

# perform test
pValues = lrgpr_batch( fam$phenotype ~ X[,1]*X[,j], loop="X[,j]", decomp, terms=c(2,3,4), delta=fitnull$delta, nthreads=4)



# Low rank analysis like FaST-LMM
#################################

# use only the first 100 principal components in the analysis
fitnull = lrgpr( fam$phenotype ~ fam$sex, decomp, rank=100)

# Use a Singular Value Decomposition (SVD) for low rank analysis
X = read.tped( paste( .libPaths(), "/lrgpr/data/test.tped", sep=''), missing='mean', quiet=TRUE)$X

# Use all markers to construct the SVD, or use a filtering approach to 
# 	use only a subset of markers as per Listgarten, et al. Nature Method, 2012
#	for FaST-LMM-Select
decomp_svd = svd(X)

# Use all principal components from the SVD unless rank parameter is specified
fitnull = lrgpr( fam$phenotype ~ fam$sex, decomp_svd)

















# Compare lrgpr_batch to lrgpr p-values
#######################################

X = read.tped( paste( .libPaths(), "/lrgpr/data/test.tped", sep=''), missing='mean')

pv = lrgpr_batch( fam$phenotype ~ fam$sex:X[,j], loop="X[,j]", decomp, terms=c(2), delta=fit$delta, rank=100, nthreads=10)

pValues = c()
for( j in 1:ncol(X) ){

	fit = lrgpr( fam$phenotype ~ fam$sex:X[,j], decomp, delta=fit$delta, rank=100)

	pValues[j] = wald(fit, terms=2)$p.value
}

which( pValues == pv)

cor(pValues, pv)

# check the MSE between the two sets of log10 p-values
sum((log10(pValues)- log10(pv))^2)

# source("~/workspace/lrgpr/test/test_lrgpr.R")

######################## 
# Compare eigen vs SVD #
########################

n = nrow(fam)

Z = matrix(rnorm(n*10), nrow=n)
K = tcrossprod(Z)
decomp = eigen(K, symmetric=TRUE)
dcmp_svd = svd(Z)

h_sq = .6 

eta = decomp$vectors[,1:2] %*% rgamma(2, 2, 1)
error_var = (1-h_sq) / h_sq  * var(eta)
y = eta + rnorm(n, sd=sqrt(error_var))

# lrgpr
#########
fit = lrgpr( fam$phenotype ~ fam$sex, decomp, rank=10)

fitsvd = lrgpr( fam$phenotype ~ fam$sex, dcmp_svd, rank=100)

# lrgpr_batch
#########
pv = lrgpr_batch( fam$phenotype ~ fam$sex:X[,j], loop="X[,j]", decomp, terms=c(2), delta=fit$delta, rank=100, nthreads=10)

pvsvd = lrgpr_batch( fam$phenotype ~ fam$sex:X[,j], loop="X[,j]", dcmp_svd, terms=c(2), delta=fit$delta, rank=100, nthreads=10)


cor(pvsvd, pv)

# check the MSE between the two sets of log10 p-values
sum((log10(pvsvd)- log10(pv))^2)



pv = sma( y, X, as.matrix(rep(1,length(y))) ) 

pv = lrgpr_batch( fam$phenotype ~ fam$sex:X[,j], loop="X[,j]", decomp, terms=c(2), delta=fit$delta, rank=100, nthreads=3)

####################
# Cross Validation #
####################













q()
R
# load package
library(lrgpr)

# load genotypes from plink TPED format
X = read.tped( paste( .libPaths(), "/lrgpr/data/test.tped", sep='') )

# load phenotype from plink TFAM format
fam = read.tfam( paste( .libPaths(), "/lrgpr/data/test.tfam", sep='') )

# load genetic relationship matrix
K = as.matrix(read.table( paste( .libPaths(), "/lrgpr/data/K.txt", sep='') ))

# Compute principal components of genetic relationship matrix
decomp = eigen(K, symmetric=TRUE)

pv = lrgpr_batch( fam$phenotype ~ fam$sex:X[,j], loop="X[,j]", decomp=decomp, terms=c(2), rank=100, nthreads=3)


