
library(compiler) 
library(parallel)

rev_matrix = cmpfun(function( M ){

	H = M

	for(i in 1:ncol(M) ){
		H[,i] = M[,ncol(M)-i+1]
	}
	return( H )
})



fastlmm3 = cmpfun(function( Y, X, decomp, delta_grid=NULL, rank=length(Y), W_til = NULL, delta=NULL){

	U = decomp$vectors[,1:rank]
	s = abs(decomp$values[1:rank])

	if( rank > 1 ){
	#	U = rev_matrix( U )
	# 	s = rev(abs(decomp$values[1:rank]))
	}
	t_U = t( U )
	#s = rev( abs(s) )

	Xu = t_U %*% X
	Yu = t_U %*% Y

	log_interval = c(10, -10)

	n = nrow(Y)

	if( is.null(n) ){
		n = length(Y)
	}	

	cp_X_low = crossprod(X) - crossprod(Xu)
	cp_X_low_Y_low = crossprod(X, Y) - crossprod(Xu, Yu)

	if( ! is.null( W_til) ){
		Wu = t_U %*% W_til
		cp_W_low = crossprod(W_til) - crossprod(Wu)
		cp_W_low_X_low = crossprod(W_til, X) - crossprod(Wu, Xu)
		cp_W_low_Y_low = crossprod(W_til, Y) - crossprod(Wu, Yu)

		cp_W_low[] = 0
		cp_W_low_X_low[] = 0
		cp_W_low_Y_low[] = 0
		
		I_c = diag(1, ncol(W_til))
	}

	Q_XX = function(delta, obj){
		crossprod(Xu, obj$inv_s_delta_Xu) + cp_X_low / delta
	}

	Q_Xy = function(delta, obj){
		crossprod(Xu, obj$inv_s_delta_Yu) + cp_X_low_Y_low / delta
	}

	Q_rr = function(delta, obj){
		crossprod(obj$ru, obj$inv_s_delta_ru) + (crossprod(obj$r)[1] - crossprod(obj$ru)[1])/ delta
	}

	Q_XW = function(delta, obj){
		if( is.null( W_til)) return(0);
		t(crossprod(Xu, obj$inv_s_delta_Wu)) + cp_W_low_X_low / delta
	}

	Q_Wy = function(delta, obj){
		if( is.null( W_til)) return(0);
		crossprod(Wu, obj$inv_s_delta_Yu) + cp_W_low_Y_low / delta
	}

	Q_Wr = function(delta, obj){
		if( is.null( W_til)) return(0);
		cp_W_low_r = crossprod(W_til, obj$r) - crossprod(Wu, obj$ru)

		crossprod(Wu, obj$inv_s_delta_ru) + cp_W_low_r / delta
	}

	Q_WW = function(delta, obj){
		if( is.null( W_til)) return(0);
		crossprod(Wu, obj$inv_s_delta_Wu) + cp_W_low / delta
	}

	Omega_XX = function(delta, obj){
		if( is.null( W_til) )
		Q_XX(delta, obj)
		else
		Q_XX(delta, obj) + obj$eval_Q_XW_WW %*% obj$eval_Q_XW
	}

	Omega_Xy = function(delta, obj){
		if( is.null( W_til) )
		Q_Xy(delta, obj) 
		else
		Q_Xy(delta, obj) + obj$eval_Q_XW_WW %*% Q_Wy(delta, obj)
	}

	Omega_rr = function(delta, obj){
		if( is.null( W_til) )
		Q_rr(delta, obj)
		else
		Q_rr(delta, obj) + crossprod(obj$eval_Q_Wr, obj$solve_I_Q_WW) %*% obj$eval_Q_Wr 
	}

	obj = list()

	ll = function( delta, env=parent.frame() ){			

		# Eval Beta
		env$obj$inv_s_delta 	= 1/(s+delta)
		env$obj$inv_s_delta_Yu 	= env$obj$inv_s_delta * Yu
		env$obj$inv_s_delta_Xu 	= env$obj$inv_s_delta * Xu
		
		if( ! is.null( W_til) ){
			env$obj$inv_s_delta_Wu 	= env$obj$inv_s_delta * Wu
			env$obj$solve_I_Q_WW 	= solve( I_c - Q_WW(delta, env$obj) )
			env$obj$eval_Q_XW 		= Q_XW(delta, env$obj)
			env$obj$eval_Q_XW_WW = crossprod(env$obj$eval_Q_XW, env$obj$solve_I_Q_WW)
		}

		env$obj$beta = solve( Omega_XX(delta, env$obj) ) %*% Omega_Xy(delta, env$obj)

		# Eval sig_g
		env$obj$ru 				= Yu - Xu %*% env$obj$beta
		env$obj$r 				= Y - X %*% env$obj$beta
		env$obj$inv_s_delta_ru 	= env$obj$inv_s_delta * env$obj$ru
		if( ! is.null( W_til) ) env$obj$eval_Q_Wr = Q_Wr(delta, env$obj)

		env$obj$sig_g = Omega_rr(delta, env$obj)[1] / n

		if( is.null( W_til) )
		log_L = -n/2 * log(2*pi*env$obj$sig_g) - 1/2 * (sum( log(s + delta ) ) + (n-rank) * log(delta)) - n/2
		else
		log_L = -n/2 * log(2*pi*env$obj$sig_g) - 1/2 * (sum( log(s + delta ) ) + (n-rank) * log(delta)) - n/2 - 1/2 * determinant( I_c - Q_WW(delta, env$obj))$modulus[1]

		return( log_L )
	} 

	delta_optimal = c()
	ll_values = c()

	if( is.null(delta) ){
		left_value = ll( exp( log_interval[1] ) )
		right_value = ll( exp( log_interval[2] ) )
		
		delta_grid = exp(seq( log_interval[1], log_interval[2], length.out=100))

		for( i in 1:(length(delta_grid)-1) ){
			 #options(warn = i); cat("\n warn =", i, "\n")

			result = optimize( ll, c( delta_grid[i], delta_grid[i+1]), maximum=TRUE, tol=0.00000001)
			ll_values[i] = result$objective
			delta_optimal[i] = result$maximum

			warnings()
		} 

		 plot(log(delta_optimal), ll_values)

		result$objective = max( ll_values )
		result$maximum = delta_optimal[which.max(ll_values)]

		if( left_value > result$objective && left_value > right_value){
			delta = exp( log_interval[1] )
			log_L = left_value
		}else if( right_value > result$objective ){
			delta = exp( log_interval[2] )
			log_L = right_value
		}else{
			delta = result$maximum
			log_L = result$objective
		}
	}else{
		delta_optimal = append(delta_optimal, delta)
		ll_values = append(ll_values, ll(delta))
	}

	# Need to evaluate ll(), so that obj values are evaluated
	log_L = ll(delta)

	# Evaluate at beta delta
	#beta = solve( Omega_XX(delta, obj) ) %*% Omega_Xy(delta, obj)
	# sig_g = Omega_rr(delta, obj)[1] / n

	beta = obj$beta
	sig_g = obj$sig_g
	sig_e = delta * sig_g

	###################################
	# Hypothesis test using Wald test #
	###################################

	S = solve( Omega_XX(delta, obj) ) *sig_g
	sd = sqrt(diag(S))

	pValues = pnorm( abs(beta), 0, sd, lower.tail=FALSE)*2
	
	# return log-likelihood surface
	###############################

	# get degrees of freedom as a function of delta
	df_values = unlist( sapply( delta_optimal, function(delta){ sum(s[1:rank]/(s[1:rank]+delta)) } ) )

	surface = as.data.frame( cbind(delta_optimal, df_values, ll_values ) )
	colnames(surface) = c("delta", "df", "log_L")	

	df = sum(s[1:rank]/(s[1:rank]+delta))
	
	return(list( ML=log_L, delta=delta, ve=sig_e, vg=sig_g, df=df, beta=beta, pValues=pValues, surface=surface))
})







fastlmm2 = cmpfun(function( Y, X, decomp, delta_grid=NULL, rank=length(Y), W_til = NULL){

	U = decomp$vectors[,1:rank]
	s = rev(abs(decomp$values[1:rank]))

	if( rank > 1 ){
		U = rev_matrix( U )
	}
	t_U = t( U )
	#s = rev( abs(s) )

	Xu = t_U %*% X
	Yu = t_U %*% Y

	log_interval = c(10, -10)

	n = nrow(Y)

	if( is.null(n) ){
		n = length(Y)
	}	

	cp_X_low = crossprod(X) - crossprod(Xu)
	cp_X_low_Y_low = crossprod(X, Y) - crossprod(Xu, Yu)

	if( ! is.null( W_til) ){
		Wu = t_U %*% W_til
		cp_W_low = crossprod(W_til) - crossprod(Wu)
		cp_W_low_X_low = crossprod(W_til, X) - crossprod(Wu, Xu)
		cp_W_low_Y_low = crossprod(W_til, Y) - crossprod(Wu, Yu)
		I_c = diag(1, ncol(W_til))
	}

	Q_XX = function(delta){
		t(Xu) %*% ((1/(s+delta)) * Xu) + cp_X_low / delta
	}

	Q_Xy = function(delta){
		t(Xu) %*% ((1/(s+delta)) * Yu) + cp_X_low_Y_low / delta
	}

	Q_rr = function(delta, beta){
		ru = Yu - Xu %*% beta
		r = Y - X %*% beta

		t(ru) %*% ((1/(s+delta)) * ru) + (crossprod(r)[1] - crossprod(ru)[1])/ delta
	}

	Q_XW = function(delta){
		if( is.null( W_til)) return(0);
		t(t(Xu) %*% ((1/(s+delta)) * Wu)) + cp_W_low_X_low / delta
	}

	Q_Wy = function(delta){
		if( is.null( W_til)) return(0);
		t(Wu) %*% ((1/(s+delta)) * Yu) + cp_W_low_Y_low / delta
	}

	Q_Wr = function(delta, beta){
		if( is.null( W_til)) return(0);
		ru = Yu - Xu %*% beta
		r = Y - X %*% beta
		cp_W_low_r = crossprod(W_til, r) - crossprod(Wu, ru)

		t(Wu) %*% ((1/(s+delta)) * ru) + cp_W_low_r / delta
	}

	Q_WW = function(delta){
		if( is.null( W_til)) return(0);
		t(Wu) %*% ((1/(s+delta)) * Wu) + cp_W_low / delta
	}

	Omega_XX = function(delta){
		if( is.null( W_til) )
		Q_XX(delta)
		else
		Q_XX(delta) + t(Q_XW(delta)) %*% solve( I_c - Q_WW(delta) ) %*% Q_XW(delta)
	}

	Omega_Xy = function(delta){
		if( is.null( W_til) )
		Q_Xy(delta) 
		else
		Q_Xy(delta) + t(Q_XW(delta)) %*% solve( I_c - Q_WW(delta) ) %*% Q_Wy(delta)
	}

	Omega_rr = function(delta, beta){
		if( is.null( W_til) )
		Q_rr(delta, beta)
		else
		Q_rr(delta, beta) + t(Q_Wr(delta, beta)) %*% solve( I_c - Q_WW(delta) ) %*% Q_Wr(delta, beta)
	}

	ll = function( delta ){			

		beta = solve( Omega_XX(delta) ) %*% Omega_Xy(delta)

		sig_g = Omega_rr(delta, beta) / n

		if( is.null( W_til) )
		log_L = -n/2 * log(2*pi*sig_g) - 1/2 * (sum( log(s + delta ) ) + (n-rank) * log(delta)) - n/2
		else
		log_L = -n/2 * log(2*pi*sig_g) - 1/2 * (sum( log(s + delta ) ) + (n-rank) * log(delta)) - n/2 - 1/2 * determinant( I_c - Q_WW(delta))$modulus[1]

		return( log_L )
	} 

	l = function(delta){

		beta = solve( Omega_XX(delta) ) %*% Omega_Xy(delta)

		sig_g = Omega_rr(delta, beta) / n

		logDet = determinant(tcrossprod(U, diag(s)) %*% t(U) + diag(delta, n) - tcrossprod(W_til))$modulus[1]

		-n/2*log(2*pi*sig_g) - 1/2 * logDet - n/2
	}


	left_value = ll( exp( log_interval[1] ) )
	right_value = ll( exp( log_interval[2] ) )
	
	delta_grid = exp(seq( log_interval[1], log_interval[2], length.out=100))
	

	delta_optimal = c()
	ll_values = c()

	for( i in 1:(length(delta_grid)-1) ){
		 #options(warn = i); cat("\n warn =", i, "\n")

		result = optimize( ll, c( delta_grid[i], delta_grid[i+1]), maximum=TRUE, tol=0.0000001)
		ll_values[i] = result$objective
		delta_optimal[i] = result$maximum

		warnings()
	} 

	 plot(log(delta_optimal), ll_values)

	result$objective = max( ll_values )
	result$maximum = delta_optimal[which.max(ll_values)]

	if( left_value > result$objective && left_value > right_value){
		delta = exp( log_interval[1] )
		log_L = left_value
	}else if( right_value > result$objective ){
		delta = exp( log_interval[2] )
		log_L = right_value
	}else{
		delta = result$maximum
		log_L = result$objective
	}

	# Evaluate at beta delta
	beta = solve( Omega_XX(delta) ) %*% Omega_Xy(delta)

	sig_g = Omega_rr(delta, beta)[1] / n

	sig_e = delta * sig_g

	###################################
	# Hypothesis test using Wald test #
	###################################

	S = solve( Omega_XX(delta) ) *sig_g
	sd = sqrt(diag(S))

	pValues = pnorm( abs(beta), 0, sd, lower.tail=FALSE)*2
	
	# return log-likelihood surface
	###############################

	# get degrees of freedom as a function of delta
	df_values = unlist( sapply( delta_optimal, function(delta){ sum(s[1:rank]/(s[1:rank]+delta)) } ) )

	surface = as.data.frame( cbind(delta_optimal, df_values, ll_values ) )
	colnames(surface) = c("delta", "df", "log_L")	

	df = sum(s[1:rank]/(s[1:rank]+delta))
	
	return(list( ML=log_L, delta=delta, ve=sig_e, vg=sig_g, df=df, beta=beta, pValues=pValues, surface=surface))
})






fastlmm = cmpfun(function( Y, X, K, version="standard", decomp=NULL, delta_grid=NULL, returnSurfaceOnly=FALSE, rank=length(Y), W_til = NULL){

	# if eigen decomposition is not passed as an argument
	if( is.null(decomp) ){	
		decomp = eigen( K, symmetric=TRUE)
	}

	U = decomp$vectors[,1:rank]
	s = rev(abs(decomp$values[1:rank]))

	if( rank > 1 ){
		U = rev_matrix( U )
	}
	t_U = t( U )
	#s = rev( abs(s) )

	Xu = t_U %*% X
	Yu = t_U %*% Y

	log_interval = c(10, -10)

	n = nrow(Y)

	if( is.null(n) ){
		n = length(Y)
	}	

	if( version == "standard" ){
		ll = function( delta ){
			#beta = solve( t(Xu) %*% diag(1/(s+delta)) %*% Xu ) %*% t(Xu) %*% diag(1/(s+delta)) %*% Yu
		
			J = ((1/(s+delta)) * Xu)
			beta = solve( t(Xu) %*% J ) %*% t(J) %*% Yu

			r = Yu - Xu %*% beta
			log_L = -0.5 * ( n * log(2*pi) + sum( log(s + delta ) ) + n + n * log( 1/n * sum( r^2 / (s + delta )) ))

			#sig_g = sum( (r^2) / (s+delta)) / n
			#-0.5 * ( n * log(2*pi) + sum( log(s + delta ) ) + n + n * log( sig_g ) )

			return( log_L )
		} 
	}else if( version == "chisq" ){

		nu_a = 2
		nu_e = 2

		# chisq prior on precision is WRONG!!
		ll = function( delta ){
			#beta = solve( t(Xu) %*% diag(1/(s+delta)) %*% Xu ) %*% t(Xu) %*% diag(1/(s+delta)) %*% Yu
		
			J = ((1/(s+delta)) * Xu)
			beta = solve( t(Xu) %*% J ) %*% t(J) %*% Yu

			r = Yu - Xu %*% beta
			sig_g = (1 +sum( r^2 / (s + delta ) )) / (n+nu_a+1/2)
			log_L = -0.5 * ( n * log(2*pi*sig_g) + sum( log(s + delta ) ) + 1/sig_g * sum( r^2 / (s + delta ) ) ) - (nu_a/2+1)*log(sig_g) - 1/(2*sig_g)  + df(nu_e/nu_a*delta, nu_a, nu_e, log=TRUE)
			
			return( log_L )
		} 

		# inverse-chisq prior on variance components
		ll = function( delta ){

			J = ((1/(s+delta)) * Xu)
			beta = solve( t(Xu) %*% J ) %*% t(J) %*% Yu

			r = Yu - Xu %*% beta
			sig_g = (1 +sum( r^2 / (s + delta ) )) / (n+nu_a+0.5)
	
			log_L = -0.5 * ( n * log(2*pi*sig_g) + sum( log(s + delta ) ) + 1/sig_g * sum( r^2 / (s + delta ) ) ) 

			sig_e = (delta * sig_g)

			prior = -nu_a/2*log(2) - lgamma(nu_a/2) - (nu_a/2+1)*log(sig_g) - 1/(2*sig_g) -nu_e/2*log(2) - lgamma(nu_e/2) - (nu_e/2+1)*log(sig_e) - 1/(2*sig_e)
			
			return(log_L + prior)
		}
	
	}else if( version == "lowrank" ){
		
		Y_low = Y - U %*% Yu
		X_low = X - U %*% Xu		

		ll3 = function( delta ){

			J = ((1/(s+delta)) * Xu)
			beta = solve( t(Xu) %*% J + crossprod(X_low)/delta ) %*% (t(J) %*% Yu + (t(X_low) %*% Y_low)/delta )

			Q = crossprod(Y_low - X_low %*% beta)[1]

			r = Yu - Xu %*% beta
			log_L = -0.5 * ( n * log(2*pi) + sum( log(s + delta ) ) + (n-rank) * log(delta)) - 0.5*( n + n*log( ( sum( r^2 / (s + delta ))  + Q/delta )/n ) )

			return( log_L )
		} 

		cp_X_low = crossprod(X) - crossprod(Xu)
		cp_X_low_Y_low = crossprod(X, Y) - crossprod(Xu, Yu)

		ll = function( delta ){			

			J = ((1/(s+delta)) * Xu)
			beta = solve( t(Xu) %*% J + cp_X_low/delta ) %*% (t(J) %*% Yu + (cp_X_low_Y_low/delta ))

			r = Yu - Xu %*% beta

			Q = crossprod( Y - X %*% beta)[1] - crossprod(r)[1]

			log_L = -0.5 * ( n * log(2*pi) + sum( log(s + delta ) ) + (n-rank) * log(delta)) - 0.5*( n + n*log( ( sum( r^2 / (s + delta ))  + Q/delta )/n ) )

			return( log_L )
		} 

	}else if( version == "lowrank_new" ){

		cp_X_low = crossprod(X) - crossprod(Xu)
		cp_X_low_Y_low = crossprod(X, Y) - crossprod(Xu, Yu)

		if( ! is.null( W_til) ){
			cp_W_low = crossprod(W_til) - crossprod(Wu)
			cp_W_low_X_low = crossprod(W_til, X) - crossprod(Wu, Xu)
			cp_W_low_Y_low = crossprod(W_til, Y) - crossprod(Wu, Yu)
			I_c = diag(1, ncol(W_til))
			Wu = t_U %*% W_til
		}

		Q_XX = function(delta){
			t(Xu) %*% ((1/(s+delta)) * Xu) + cp_X_low / delta
		}

		Q_Xy = function(delta){
			t(Xu) %*% ((1/(s+delta)) * Yu) + cp_X_low_Y_low / delta
		}

		Q_rr = function(delta, beta){
			ru = Yu - Xu %*% beta
			r = Y - X %*% beta

			t(ru) %*% ((1/(s+delta)) * ru) + (crossprod(r)[1] - crossprod(ru)[1])/ delta
		}

		Q_XW = function(delta){
			if( is.null( W_til)) return(0);
			t(Xu) %*% ((1/(s+delta)) * Wu) + cp_W_low_X_low / delta
		}

		Q_Wy = function(delta){
			if( is.null( W_til)) return(0);
			t(Wu) %*% ((1/(s+delta)) * Yu) + cp_W_low_Y_low / delta
		}

		Q_Wr = function(delta, beta){
			if( is.null( W_til)) return(0);
			ru = Yu - Xu %*% beta
			cp_W_low_r = crossprod(W_til, r) - crossprod(Wu, ru)

			t(Wu) %*% ((1/(s+delta)) * ru) + cp_W_low_r / delta
		}

		Q_WW = function(delta){
			if( is.null( W_til)) return(0);
			t(Wu) %*% ((1/(s+delta)) * Wu) + cp_W_low / delta
		}

		Omega_XX = function(delta){
			if( is.null( W_til) )
			Q_XX(delta)
			else
			Q_XX(delta) + Q_XW(delta) %*% solve( I_c - Q_WW(delta) ) %*% Q_XW(delta)
		}

		Omega_Xy = function(delta){
			if( is.null( W_til) )
			Q_Xy(delta) 
			else
			Q_Xy(delta) + Q_XW(delta) %*% solve( I_c - Q_WW(delta) ) %*% Q_Wy(delta)
		}

		Omega_rr = function(delta, beta){
			if( is.null( W_til) )
			Q_rr(delta, beta)
			else
			Q_rr(delta, beta) + Q_Wr(delta, beta) %*% solve( I_c - Q_WW(delta) ) %*% Q_Wr(delta, beta)
		}

		ll = function( delta ){			

			beta = solve( Omega_XX(delta) ) %*% Omega_Xy(delta)

			sig_g = Omega_rr(delta, beta) / n

			log_L = -n/2 * log(2*pi*sig_g) - 1/2 * (sum( log(s + delta ) ) + (n-rank) * log(delta)) - 1/2

			return( log_L )
		} 




	}else if( version == "lowrank_chisq" ){
		
		Y_low = Y - U %*% Yu
		X_low = X - U %*% Xu		

		nu_a = 2
		nu_e = 2 
		ll = function( delta ){

			J = ((1/(s+delta)) * Xu)
			beta = solve( t(Xu) %*% J + crossprod(X_low)/delta ) %*% (t(J) %*% Yu + (t(X_low) %*% Y_low)/delta )

			Q = crossprod(Y_low - X_low %*% beta)[1]

			r = Yu - Xu %*% beta
			
			sig_g = ( 1 + sum( r^2 / (s + delta ))  + Q/delta ) / (n+nu_a+1/2)
		
			#log_L = -0.5 * ( n * log(2*pi*sig_g) + sum( log(s + delta ) ) + (n-rank) * log(delta)) - 0.5 * 1/sig_g * ( sum( r^2 / (s + delta ))  + 1/delta * Q ) - (nu_a/2+1)*log(sig_g) - 1/(2*sig_g)  + log(df(nu_e/nu_a*delta, nu_a, nu_e))

			log_L = -(n/2+nu_a/2+1)*log(sig_g) - (n + nu_a+0.5)/2 + -0.5*(sum(log(s+delta)) +(n-rank) * log(delta) ) + log(df(nu_a/nu_e*delta, nu_a, nu_e)) - n/2*log(2*pi) - nu_a/2*log(2) - lgamma(nu_a/2)

			return( log_L )
		} 

	}else if( version == "lowrank_test" ){
		ll = function( delta ){
			#beta = solve( t(Xu) %*% diag(1/(s+delta)) %*% Xu ) %*% t(Xu) %*% diag(1/(s+delta)) %*% Yu
		
			J = ((1/(s+delta)) * Xu)
			beta = solve( t(Xu) %*% J ) %*% t(J) %*% Yu

			r = Yu - Xu %*% beta
			log_L = -0.5 * ( n * log(2*pi) + sum( log(s + delta ) ) + n + n * log( 1/n * sum( r^2 / (s + delta ))))

			return( log_L )
		} 

	}else if( version == "REML" ){
		
		if( 0 ){
			# From Lippert, et al. Nature Methods 2011
			A = (diag(1, n) - U %*% t(U)) %*% X
			cpA = crossprod(A)

			log_det_cpX = determinant(crossprod(X))$modulus[1] 
		

			ll = function( delta ){
				#beta = solve( t(Xu) %*% diag(1/(s+delta)) %*% Xu ) %*% t(Xu) %*% diag(1/(s+delta)) %*% Yu
		
				J = ((1/(s+delta)) * Xu)
				beta = solve( t(Xu) %*% J ) %*% t(J) %*% Yu
	
				r = Yu - Xu %*% beta
				sig_g = (1/2+sum( r^2 / (s + delta ) )) / (n-d)
				log_L_ML = -0.5 * ( n * log(2*pi*sig_g) + sum( log(s + delta ) ) + 1/sig_g * sum( r^2 / (s + delta ) )) 

				log_REML1 = 0.5 * ( d*log(2*pi*sig_g) + log_det_cpX )			
				log_REML2 = - 0.5 * determinant( (t(Xu) %*% ((s+delta) * Xu) ) + cpA/delta )$modulus[1]	

				return( log_L_ML + log_REML1 + log_REML2 )
			} 
		}
		
		d = ncol(Xu)

		S = diag(1, n) - X%*% solve(crossprod(X)) %*% t(X)

		decomp_reml = eigen( S %*% K %*% S, symmetric=TRUE)

		eta_sq = (t(decomp_reml$vectors[,1:(n-d)]) %*% Y) ^2

		# from Kang, et al. Genetics 2008
		# gives same results as emma.REMLE( Y, X, K )
		ll = function( delta ){			

			log_L = 0.5 * ( (n-d) *log( (n-d) / (2*pi) ) - (n-d) - (n-d) * log( sum( eta_sq / (decomp_reml$values[1:(n-d)] + delta) ) ) - sum( log( decomp_reml$values[1:(n-d)] + delta) ) )

			return( log_L )
		}  # 
	}else{
		cat("Likelihood function not defined: ", version, "\n")
		stop()
	}


	left_value = ll( exp( log_interval[1] ) )
	right_value = ll( exp( log_interval[2] ) )

	if( is.null(delta_grid) ){
		delta_grid = exp(seq( log_interval[1], log_interval[2], length.out=100))
	}

	if( returnSurfaceOnly ){

		ll_values = unlist(sapply(delta_grid, ll))		
		df_values = unlist( sapply( delta_grid, function(delta){ sum(s/(s+delta)) } ) )

		# return log-likelihood surface
		surface = as.data.frame( cbind(delta_grid, df_values, ll_values ) )
		colnames(surface) = c("delta", "df", "log_L")	

		return( surface )	
	}	

	if( length(delta_grid) > 1 ){

		delta_optimal = c()
		ll_values = c()

		for( i in 1:(length(delta_grid)-1) ){

			result = optimize( ll, c( delta_grid[i], delta_grid[i+1]), maximum=TRUE, tol=0.000001)
			ll_values[i] = result$objective
			delta_optimal[i] = result$maximum
		} 

		plot(log(delta_optimal), ll_values, main=version, ylim=c(max(max(ll_values)-50, min(ll_values)), max(ll_values) ))
	
		result$objective = max( ll_values )
		result$maximum = delta_optimal[which.max(ll_values)]

		if( left_value > result$objective && left_value > right_value){
			delta = exp( log_interval[1] )
			log_L = left_value
		}else if( right_value > result$objective ){
			delta = exp( log_interval[2] )
			log_L = right_value
		}else{
			delta = result$maximum
			log_L = result$objective
		}
	}else{
		result = list()
		log_L = ll(delta_grid)
		delta = delta_grid

		delta_optimal = delta
		ll_values = log_L		
	}
	
	# calculate sig_g
	if( version %in% c("lowrank", "lowrank_chisq", "lowrank_new") ){

		J = ((1/(s+delta)) * Xu)
		beta = solve( t(Xu) %*% J + crossprod(X_low)/delta ) %*% (t(J) %*% Yu + (t(X_low) %*% Y_low)/delta )

		Q = crossprod(Y_low - X_low %*% beta)[1]

		r = Yu - Xu %*% beta
		
		if( version == "lowrank_chisq" ){		
			sig_g = ( 1 + sum( r^2 / (s + delta ))  + Q/delta ) / (n+nu_a+1/2)
		}else{
			sig_g = ( sum( r^2 / (s + delta ))  + Q/delta ) / n
		}
		sig_e = delta * sig_g

	}else{
		J = ((1/(s+delta)) * Xu)
		beta = solve( t(Xu) %*% J ) %*% t(J) %*% Yu
		r = Yu - Xu %*% beta

		if( version == "standard"){
			sig_g = 1/n * sum( (r^2) / (s+delta))
			sig_e = delta * sig_g

		}else if( version == "REML"){			
			sig_g = 1/n * sum( (r^2) / (s+delta))
			sig_e = delta * sig_g
		}else if( version == "chisq"){			
			sig_g = (1/2+sum( r^2 / (s + delta ) )) / (n+nu_a+1/2)
			sig_e = delta * sig_g
		}else{
			stop("error")
		}
	}

	###################################
	# Hypothesis test using Wald test #
	###################################

	if( version == "standard" || version == "chisq"){
		J = ((1/(s+delta)) * Xu)
		S = solve( t(Xu) %*% J )*sig_g
		sd = sqrt(diag(S))

		pValues = pnorm( abs(beta), 0, sd, lower.tail=F)*2
	}else if( version == "REML" ){
		pValues = rep(NA, length(beta))
	}else{
		J = ((1/(s+delta)) * Xu)
		S = solve( t(Xu) %*% J + crossprod(X_low)/delta )*sig_g
		sd = sqrt(diag(S))

		pValues = pnorm( abs(beta), 0, sd, lower.tail=F)*2
	}

	# return log-likelihood surface
	###############################

	# get degrees of freedom as a function of delta
	df_values = unlist( sapply( delta_optimal, function(delta){ sum(s[1:rank]/(s[1:rank]+delta)) } ) )

	surface = as.data.frame( cbind(delta_optimal, df_values, ll_values ) )
	colnames(surface) = c("delta", "df", "log_L")	

	df = sum(s[1:rank]/(s[1:rank]+delta))
	
	return(list( ML=log_L, delta=delta, ve=sig_e, vg=sig_g, df=df, beta=beta, pValues=pValues, surface=surface))
})


lmm_confidenceInterval = function( surface, decomp=NULL, rank){

	# Evalute confidence interval
	delta_best = surface$delta[which.max(surface$log_L)]
	# surface$df[which.max(surface$log_L)]

	end = which.max(surface$log_L)

	i = which.min( abs(surface$log_L[1:end] - (max(surface$log_L) - qchisq(.975, 1)/2) ) )
	log_L_left = surface$log_L[1:end][i]
	delta_left = surface$delta[1:end][i]

	i = which.min( abs(surface$log_L[which.max(surface$log_L):length(surface$log_L)] - (max(surface$log_L) - qchisq(.975, 1)/2) ) )
	log_L_right = surface$log_L[which.max(surface$log_L):length(surface$log_L)][i]
	delta_right = surface$delta[which.max(surface$log_L):length(surface$log_L)][i]

	p_left = pchisq( 2*(max(surface$log_L) - log_L_left), 1, lower.tail=F)
	p_right = pchisq( 2*(max(surface$log_L) - log_L_right), 1)

	if( ! is.null( decomp ) ){

		# sinace df and delta and inversely related, switch left/right names
		df_right = sum(decomp$values[1:rank]/(decomp$values[1:rank]+delta_left))
		df_left = sum(decomp$values[1:rank]/(decomp$values[1:rank]+delta_right))
	}else{
		df_left = NA 
		df_right = NA
	}
	
	return( list( 	delta_left = delta_left,
			delta_best = delta_best, 
			delta_right = delta_right, 
			p_left = p_left, 
			p_right = p_right, 
			df_left = df_left, 
			df_right = df_right))
}


# Near mode, delta
plot_lmm = function( surface, new=TRUE, xlim=NULL, df=FALSE, col="black", main=NULL){

	ci = lmm_confidenceInterval( surface )

	delta_best = ci$delta_best
	delta_left = ci$delta_left
	delta_right = ci$delta_right

	if( df ){
		key = "df"
		xlab = "effective degrees of freedom"
	}else{
		key = "delta"
		xlab = "delta"
	}

	surface = as.list( surface )

	if( is.null(xlim) ){
		# set x-axis range based on confidence interval
		i = which.min( abs(delta_left - surface$delta))
		bound_left = which.min( abs(max(surface$log_L) - surface$log_L[1:i] - 3))
		xmin = surface$delta[1:i][ bound_left ]

		l = length(surface$log_L)

		i = which.min( abs(delta_right - surface$delta))
		bound_right = which.min( abs(max(surface$log_L) - surface$log_L[i:l] - 3))
		xmax = surface$delta[i:l][ bound_right ]

		xlim = c(xmin, xmax)
		
		surface_local = surface$log_L - min(surface$log_L[bound_left:(bound_right+i-1)])
		surface_local = surface_local / max(surface_local[bound_left:(bound_right+i-1)])

		ymin = max(surface$log_L) - min(surface$log_L[bound_left:(bound_right+i-1)])

		# convert xlim in delta to xlim in df, in needed
		if( df ){

			i = which( surface$delta == xlim[1] )
			j = which( surface$delta == xlim[2] )

			xlim = c(surface$df[j], surface$df[i] )
		}


	}else{		
		surface_local = surface$log_L - min(surface$log_L)
		surface_local = surface_local / max(surface_local)
	}
	

	if( new ){

		if( is.null(main) ){
			main = "Log-likelihood surface of linear mixed model"
		}

		plot( surface[[key]], surface_local , type='l', col=col, lwd=4, ylab="scaled log-likelihood", main=main, xlim=xlim, yaxt='n', ylim=c(0, 1),  xlab=xlab, cex=1.3) # 

		axis(2, at=c(1, 2/3, 1/3, 0), labels=c(0,-1, -2, -3) )

	}else{
		lines( surface[[key]], surface_local, col=col, lwd=3)
	}

	# plot confidence interval
	##########################
	i = which.min( abs(delta_best - surface$delta))
	points( surface[[key]][i], surface_local[i], pch=20, cex=3, col=col)

	i = which.min( abs(delta_left - surface$delta))
	points( surface[[key]][i], surface_local[i], pch='|', cex=3)

	i = which.min( abs(delta_right - surface$delta))
	points( surface[[key]][i], surface_local[i], pch='|', cex=3, lwd=3)
}


if( 0){
library(geoR)


mytlm = function( Y, X, v ){

	n = length(Y)

	# initialize parameters using Gaussian model
	beta = chol2inv(chol( t(X) %*% X ) ) %*% t(X) %*% Y
	r = Y - X %*% beta
	sigma_sq = sum(r^2)/n	

	w = rep(1, n)

	log_L = c()
	sig = c()
	w_mean = c()
	beta1 = c()
	log_L_complete = c()
	i = 1

	while(1){

		w = as.vector( (v+1) / (r^2 + v*sigma_sq) )

		#beta = solve( ( t(X) * w) %*% X) %*% (t(X) *w) %*% Y
		beta = lm.wfit( X, Y, w)$coefficients
		
		r = Y - X %*% beta	
	
		sigma_sq = sum(r *w *r) / n		

		sig[i] = sigma_sq
		w_mean[i] = w[1]
		beta1[i] = beta[1]

		# Student-t log-likelihood
		log_L[i] = -n/2*log(sigma_sq) - (v+1)/2 * sum(log(1+r^2/(v*sigma_sq) )) + n*(lgamma((v+1)/2) - lgamma(v/2) - 1/2*log(pi))
		#log_L_complete[i] = -sum(log(tau)/2) - sum(r^2/(2*tau)) + v*n/2*log(sigma_sq) - sum((v/2+1)*log(tau)) - sum(v*sigma_sq/(2*tau))

		if( i> 10 && abs(log_L[i] - log_L[i-1]) < 1e-4 ){
			break;
		}
	
		i = i + 1		
	}

	plot(log_L)




	
	#plot(log_L_complete)

	#plot(w)

	# #
	return( list(r=r, w=w, log_L=log_L[i]))
}


library(colorRamps)

df = c(3, 4,5,6,7, 8,9,10, 100, 500, 1000, 1e4, 1e5, 1e6, 1e7)
col = colorRampPalette(c("orange", "red", "blue"))(length(df))

plot(1, type='n', ylim=c(0, 1), xlim=c(-25, 25), ylab="influence metric", xlab="residual")

for( i in 1:length(df) ){

	fit = mytlm( Y, X, df[i] )
	
	points(fit$r, fit$w, col=col[i])
	
	cat(fit$log_L, "\n")
}

legend("topleft", legend=df, fill=col)


#plot(density(Y-mean(Y)))

x = seq(-30, 30, .01)
lines(x, dnorm(x, 0, sd(Y)), col="red")

lines(x, dt(x, df=1000), col="blue")


#tlm(Y~X-1)



#beta = solve( ( t(X) * w) %*% X) %*% (t(X) *w) %*% Y
beta = lm.wfit( X, Y, w)$coefficients

lm.fit( X, Y, w)$coefficients


}





#rare variants revolution












if( 0){

stop()

X =  cbind(1, Xm)

emma.MLE(Y, X , K)

fastlmm(Y, X , K)


fastlmm_chisq(Y, X , K)




K = tcrossprod( Xm )

write.table(Y, "Y.txt", row.names=F, col.names=F, quote=F)
write.table(K, "K.txt", row.names=F, col.names=F, quote=F)
write.table(Xm, "X.txt", row.names=F, col.names=F, quote=F)

 delta = seq(1.3,1.6, length.out=100)

log_L = sapply( delta, ll)

plot( delta, log_L ,type='l')



Y = as.matrix(read.table("Y.txt"))
X = as.matrix(read.table("X.txt"))
K = as.matrix(read.table("K.txt"))

library(emma) 

emma.MLE(Y, X , K)





	library(multicore)

	# Make plots of log-likelihood surface

	ll_uniform = function( delta ){
		#beta = solve( t(Xu) %*% diag(1/(s+delta)) %*% Xu ) %*% t(Xu) %*% diag(1/(s+delta)) %*% Yu
		
		J = ((1/(s+delta)) * Xu)
		beta = solve( t(Xu) %*% J ) %*% t(J) %*% Yu

		r = Yu - Xu %*% beta
		log_L = -0.5 * ( n * log(2*pi) + sum( log(s + delta ) ) + n + n * log( 1/n * sum( r^2 / (s + delta ))))

		return( log_L )
	} 
	
	delta = sort(c(seq(exp(-12), exp(-8), length.out=1), seq(exp(-20), exp(-0), length.out=500), seq(exp(-0), exp(4), length.out=20), seq(exp(-10), exp(10), length.out=1000), sig_e/sig_g))	
	
	v = unlist(mclapply(delta, ll_uniform))

	# the confidence interval for delta is HUGE! 9 orders of magnitude 
	log_L = max(v)
	delta_best = sig_e/sig_g # delta[which.max(v)]
	i = which.min( abs(v[1:which.max(v)] - (log_L - qchisq(.975, 1)/2) ) )
	left = v[1:which.max(v)][i]
	delta_left = delta[1:which.max(v)][i]

	j = which.min( abs(v[which.max(v):length(v)] - (log_L - qchisq(.975, 1)/2) ) )
	right = v[which.max(v):length(v)][j]
	delta_right = delta[which.max(v):length(v)][j]

	pchisq( 2*(log_L - left), 1)
	pchisq( 2*(log_L - right), 1)

	delta_left
	delta_best
	delta_right

	png("LMM_log_likelihood_continuous.png")
	y = unlist(mclapply(delta, ll_uniform))
	plot(log(delta), y, type='l', col="red", lwd=3, ylab="log-likelihood", main="Log-likelihood surface of linear mixed model", ylim=c(y[length(y)*.6], max(y)) )
	
	y = unlist(mclapply(delta, ll))
	lines(log(delta), y, col="blue", lwd=3)
	legend("bottomleft", legend=c("log_L w/ uniform prior", "log_L w/ chisq prior"), fill=c("red", "blue"))
	
	i = which.min( abs(sig_e/sig_g - delta))
	points( log(delta[i]), y[i], pch=20, cex=3)

	i = which.min( abs(delta_left - delta))
	points( log(delta[i]), y[i], pch='|', cex=2)
	
	i = which.min( abs(delta_right - delta))
	points( log(delta[i]), y[i], pch='|', cex=2)

	dev.off()
	
	y = sapply(delta, ll)
	y = y - min(y)
	y = y / max(y)
	plot(log(delta), y, type='l', col="red", lwd=3, ylab="scaled log-likelihood", main="Log-likelihood surface of linear mixed model")
	
	y = sapply(delta, ll_uniform)
	y = y - min(y)
	y = y / max(y)
	lines(log(delta), y, col="blue", lwd=3)
	legend("bottomleft", legend=c("log_L w/ chisq prior", "log_L w/ uniform prior"), fill=c("red", "blue"))

	y = df(delta, 2, 2, log=T)
	y = y - min(y)
	y = y / max(y)
	lines( log(delta), y, type='l', col="green", lwd=3)
	legend("bottomleft", legend=c("log_L w/ chisq prior", "log_L w/ uniform prior", "chisq prior"), fill=c("red", "blue", "green"))

	y = log(1/delta)
	y = y - min(y)
	y = y / max(y)
	lines( log(delta), y, type='l', col="darkgreen", lwd=3)



	a = runif( 1e6, 0, 1)
	b = runif(  1e6, 0, 1)

	plot(density(a/b), xlim=c(0, 1000))

	
	

	sig_a = rchisq(1e6, 2)
	sig_e = rchisq(1e6, 2)

	dens = density(log(sig_a/(sig_e)), from=0)
	plot(dens)

	# log scale for delta
	plot( log(delta), df(delta, 2, 2, log=F), type='l', col="green", lwd=3)
	lines( log(delta), pf(delta, 2, 2, log=F), type='l', col="red", lwd=3)	
	legend("topright", legend=c("PDF", "CDF"), fill=c("green", "red"))

	# standard scale
	plot( delta, df(delta, 2, 2, log=F), xlim=c(0, 10), type='l', col="green", lwd=3)
	lines( delta, pf(delta, 2, 2, log=F), type='l', col="red", lwd=3)
	legend("topright", legend=c("PDF", "CDF"), fill=c("green", "red"))

	
	# standard scale
	
	delta = seq(exp(-4), exp(3), length.out=1000)
	plot( delta, df(delta, 2, 2, log=F), xlim=c(0, 10), type='l', col="green", lwd=3)
	lines( delta, pf(delta, 2, 2, log=F), type='l', col="red", lwd=3)
	legend("topright", legend=c("PDF", "CDF"), fill=c("green", "red"))


	h_sq = seq(0, 1, length.out=1000)
	plot( h_sq, dbeta(h_sq, 1,1), type='l', col="green")


	plot( log(dens$x), log(dens$y))





	d = seq(0, 1, by=0.01)
	plot( d, dbeta(d, nu_e/2, nu_a/2), xlab="heritability", ylab="prior")
	}



#Xu = t_U %*% X


#Xu = t_U %*% X[,1:99]















