
sudo apt-get install libgsl0-dev
sudo apt-get install libboost-dev


http://www.gnu.org/software/gsl/




library(lrgpr)



# Plink files
tped_file = paste(system.file( package = 'lrgpr'), "/extdata/test.tped", sep="")
fam_File =  paste(system.file( package = 'lrgpr'), "/extdata/test.tfam", sep="")

# Convert TPED file to binary format
# Create a binary data file: test.binary
# 	and a binary file describing this data: test.binary_descr
convertToBinary(tped_file, "./test.binary", "TPED")

# attach data by reading the description file
X <- attach.big.matrix("/data/test_space/test.binary_descr")


FAM = read.tfam( fam_File )

y = FAM$phenotype
sex = FAM$sex

# Single marker analysis
pValues = glmApply( y ~ SNP + sex, features=X, terms=c(2))$pValues


pValues = glmApply( y ~ sex + SNP:X[,1], features=X, terms=c(3:5))$pValues


# Full rank linear mixed model
i = seq(1, ncol(X), by=100)

K = tcrossprod(scale(set_missing_to_mean(X[,i])))

dcmp = eigen(K, symmetric=TRUE)

# Linear mixed model analysis using markers selected by GCV
pValuesLMM_full = lrgprApply( y ~ SNP, features=X, decomp=dcmp, terms=c(2))


dcmp = svd(scale(set_missing_to_mean(X[,2:5])))
summary(lrgpr(y ~ X[,1], decomp=dcmp))$coefficients

dcmp = svd(scale(set_missing_to_mean(X[,1:5])))
summary(lrgpr(y ~ X[,1], decomp=dcmp, W_til=scale(X[,1])))$coefficients


dcmp = svd(scale(set_missing_to_mean(X[,1:5])))
summary(lrgpr(y ~ X[,1], decomp=dcmp, W_til=X[,1]))$coefficients






#################################################
# Learn the rank of random effect from the data #
#################################################

ord = order(pValues, decreasing=FALSE)

# Evaluate cross-validation for multiple rank values
fitcv = cv.lrgpr( y ~ sex, features=X, order=ord )

# Evaluate model criterion for multiple rank values using the degrees of freedom statistic
# Show Akaike Information Criterion (AIC), Bayesian Information Criterion (BIC) and generalized cross-validation (GCV)
fitcrit = criterion.lrgpr( y ~ sex, features=X, order=ord )

# Plot the cross-validation and model crition curves
par(mfrow=c(1,2))
plot.cv.lrgpr(fitcv)
plot.criterion.lrgpr(fitcrit)

#######################################################################
# Apply Linear Mixed Model analysis using the markers selected by GCV #
#######################################################################

# Perform singular value decomposition of the subset of markers
dcmp = svd(scale(set_missing_to_mean(X[,ord[1:fitcrit$best$GCV]])))

#############################################
# Evaluate the Linear Mixed Model by itself #
#############################################
fit = lrgpr(y ~ sex, dcmp)

par(mfrow=c(2,4))
plot(fit)
plot(lm(y ~ sex))

MAP = read.table("/data/test_space/MESA/MESA_Euro_nvtrg31c/MESA_complete.map")

# Linear mixed model analysis using markers selected by GCV
pValuesLMM = lrgprApply( y ~ SNP, features=X, decomp=dcmp, terms=c(2))






q()
R
library(lrgpr)



# Plink files
tped_file = paste(system.file( package = 'lrgpr'), "/extdata/test.tped", sep="")
fam_File =  paste(system.file( package = 'lrgpr'), "/extdata/test.tfam", sep="")

# attach data by reading the description file
X <- attach.big.matrix("/data/test_space/test.binary_descr")

FAM = read.tfam( fam_File )

y = FAM$phenotype
sex = FAM$sex


pValues = glmApply( y ~ sex + SNP:X[,1], features=X, terms=c(3:5), nthreads=1)$pValues


SNP = X[,1]


model.matrix.default(y ~ sex + SNP:X[,1])


q()
R

file.remove("lrgpr.aux"); Sweave('lrgpr.Rnw');  tools::texi2dvi('lrgpr.tex', pdf=T, clean=F); 

lrgprApply( y ~ sex + SNP*X[,1], features=X[,1:4], decomp=dcmp, terms=3:5)