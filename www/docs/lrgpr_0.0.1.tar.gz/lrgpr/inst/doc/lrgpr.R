### R code from vignette source 'lrgpr.Rnw'

###################################################
### code chunk number 1: lrgpr.Rnw:44-46
###################################################
prettyVersion <- packageDescription("lrgpr")$Version
prettyDate <- format(Sys.Date(), "%B %e, %Y")


###################################################
### code chunk number 2: lrgpr.Rnw:67-71
###################################################
options(prompt = "> ")
options(continue = " ")
library(lrgpr)
library(aod)


###################################################
### code chunk number 3: lrgpr.Rnw:104-107 (eval = FALSE)
###################################################
## pkgs = c("Rcpp", "RcppGSL", "RcppProgress", "MASS", "parallel", "doParallel", 
## "formula.tools", "BH", "bigmemory", "aod")
## install.packages(pkgs)


###################################################
### code chunk number 4: lrgpr.Rnw:110-111 (eval = FALSE)
###################################################
## install.packages("bigmemory", repos="http://R-Forge.R-project.org")


###################################################
### code chunk number 5: lrgpr.Rnw:134-139
###################################################
# Path to Plink files
path = system.file(package = 'lrgpr')
tped_file = paste(path, "/extdata/test.tped", sep="")
fam_file = paste(path, "/extdata/test.tfam", sep="")
map_file = paste(path, "/extdata/test.map", sep="")


###################################################
### code chunk number 6: lrgpr.Rnw:142-146
###################################################
# Convert TPED file to binary format
# Create a binary data file: test.binary
# 	and a binary file describing this data: test.binary_descr
convertToBinary(tped_file, "./test.binary", "TPED")


###################################################
### code chunk number 7: lrgpr.Rnw:153-155
###################################################
# attach data by reading the description file
X <- attach.big.matrix("./test.binary_descr")


###################################################
### code chunk number 8: lrgpr.Rnw:160-162
###################################################
# data is only loaded into memory when it is accessed
X[,10]


###################################################
### code chunk number 9: lrgpr.Rnw:167-173
###################################################
# data is only loaded into memory when it is accessed
column_means = c()

for(j in 1:ncol(X)){
	column_means[j] = mean(X[,j])
}


###################################################
### code chunk number 10: lrgpr.Rnw:180-182
###################################################
# Report allele frequencies using C/C++ backend
freq = getAlleleFreq(X)


###################################################
### code chunk number 11: lrgpr.Rnw:189-193
###################################################
# Read FAM file
FAM = read.fam(fam_file)
y = FAM$phenotype
sex = FAM$sex


###################################################
### code chunk number 12: lrgpr.Rnw:196-198
###################################################
# Fit a linear model
fit = glm( y ~ sex )


###################################################
### code chunk number 13: lrgpr.Rnw:202-204
###################################################
# Simple view
fit


###################################################
### code chunk number 14: lrgpr.Rnw:206-208
###################################################
# Expanded view
summary(fit)


###################################################
### code chunk number 15: lrgpr.Rnw:212-215
###################################################
# Plot diagnostics
par(mfrow=c(2,2))
plot(fit)


###################################################
### code chunk number 16: lrgpr.Rnw:220-222
###################################################
# Fit a linear model
fit = glm( y ~ sex + X[,10]*X[,100])


###################################################
### code chunk number 17: lrgpr.Rnw:225-228
###################################################
# Composite hypothesis test of additive and interaction terms for the two markers
# Note that wald.test is from the aod package
wald.test(vcov(fit), coef(fit), Terms=3:5)


###################################################
### code chunk number 18: lrgpr.Rnw:237-239
###################################################
# Standard GWAS regression analysis
pValues = glmApply( y ~ SNP + sex, features=X, terms=2)$pValues


###################################################
### code chunk number 19: lrgpr.Rnw:242-244
###################################################
# Standard GWAS regression analysis
pValues = glmApply( y ~ SNP + sex, features=X)$pValues


###################################################
### code chunk number 20: lrgpr.Rnw:247-256
###################################################
pValuesR = c()

for(j in 1:ncol(X)){
	# fit model
	fit = glm(y ~ X[,j] + sex)

	# perform hypothesis test
	pValuesR[j] = wald.test(vcov(fit), coef(fit), Terms=2)$result$chi2[3]
}


###################################################
### code chunk number 21: lrgpr.Rnw:290-293
###################################################
# Read in GSM and perform spectral decomposition
K = read.table( paste(path, "/extdata/K.txt", sep="") )
dcmp = eigen(K, symmetric=TRUE)


###################################################
### code chunk number 22: lrgpr.Rnw:298-300
###################################################
# Prune to every 100th marker
index = seq(1, ncol(X), by=100)


###################################################
### code chunk number 23: lrgpr.Rnw:302-308
###################################################
# Keep only SNPs where there is variation in this dataset
# With SNP data coded as 0,1,2 screening by the allele frequency would be sufficient
# But with continuous dosage data, we need to consider the variance of the SNP
v = getAlleleVariance(X[,index])

j = index[which(v > .01)]


###################################################
### code chunk number 24: lrgpr.Rnw:310-314
###################################################
# Perform spectral decomposition on the set of SNPs
# 	after replacing missing values with the per-SNP mean
# Each SNP is centered and scaled
dcmp = svd(scale(set_missing_to_mean(X[,j])))


###################################################
### code chunk number 25: lrgpr.Rnw:318-319
###################################################
fit = lrgpr(y ~ sex, dcmp)


###################################################
### code chunk number 26: lrgpr.Rnw:328-330
###################################################
# Simple view
fit


###################################################
### code chunk number 27: lrgpr.Rnw:332-334
###################################################
# Expanded view
summary(fit)


###################################################
### code chunk number 28: lrgpr.Rnw:338-341
###################################################
# Plot diagnostics
par(mfrow=c(1,4))
plot(fit)


###################################################
### code chunk number 29: lrgpr.Rnw:347-349
###################################################
# Fit a linear model
fit = lrgpr( y ~ sex + X[,10]*X[,100], dcmp)


###################################################
### code chunk number 30: lrgpr.Rnw:351-353
###################################################
# Composite hypothesis test of additive and interaction terms for the two markers
wald(fit, terms=3:5)


###################################################
### code chunk number 31: lrgpr.Rnw:362-364
###################################################
# Uncorrected single SNP test
pValues = glmApply( y ~ SNP + sex, features=X, terms=2)$pValues


###################################################
### code chunk number 32: lrgpr.Rnw:366-368
###################################################
# sort markers based on p-value
ord = order(pValues, decreasing=FALSE)


###################################################
### code chunk number 33: lrgpr.Rnw:373-375
###################################################
k = 100
dcmp = svd(scale(set_missing_to_mean(X[,ord[1:k]])))


###################################################
### code chunk number 34: lrgpr.Rnw:377-379
###################################################
# Fit the low rank model
fit = lrgpr(y ~ sex, dcmp)


###################################################
### code chunk number 35: lrgpr.Rnw:389-391
###################################################
# Evaluate cross-validation for multiple rank values
fitcv = cv.lrgpr( y ~ sex, features=X, order=ord, nfolds=2)


###################################################
### code chunk number 36: lrgpr.Rnw:395-397
###################################################
# Evaluate model criterion 
fitcrit = criterion.lrgpr( y ~ sex, features=X, order=ord )


###################################################
### code chunk number 37: lrgpr.Rnw:403-407
###################################################
# Plot the cross-validation and model crition curves
par(mfrow=c(1,2))
plot.cv.lrgpr(fitcv)
plot.criterion.lrgpr(fitcrit) 


###################################################
### code chunk number 38: lrgpr.Rnw:413-415
###################################################
k = fitcrit$best$GCV
dcmp = svd(scale(set_missing_to_mean(X[,ord[1:k]])))


###################################################
### code chunk number 39: lrgpr.Rnw:426-429
###################################################
dcmp = svd(scale(set_missing_to_mean(X[,2:5])))
fit = lrgpr(y ~ X[,1], decomp=dcmp)
summary(fit)$coefficients


###################################################
### code chunk number 40: lrgpr.Rnw:434-437
###################################################
dcmp = svd(scale(set_missing_to_mean(X[,1:5])))
fit = lrgpr(y ~ X[,1], decomp=dcmp, W_til=scale(X[,1]))
summary(fit)$coefficients


###################################################
### code chunk number 41: lrgpr.Rnw:447-449
###################################################
# Linear mixed model analysis
pValuesLMM = lrgprApply( y ~ SNP + sex, features=X, decomp=dcmp, terms=2)


###################################################
### code chunk number 42: lrgpr.Rnw:453-455
###################################################
# Test SNP x sex interaction
pv1 = lrgprApply( y ~ SNP*sex, features=X, decomp=dcmp, terms=4)


###################################################
### code chunk number 43: lrgpr.Rnw:457-459
###################################################
# Test SNP x SNP interaction
pv2 = lrgprApply( y ~ sex + SNP*X[,1], features=X, decomp=dcmp, terms=3:5)


###################################################
### code chunk number 44: lrgpr.Rnw:468-469
###################################################
MAP = read.table( map_file )


###################################################
### code chunk number 45: lrgpr.Rnw:473-476
###################################################

pValuesLMMprox = lrgprApply( y ~ sex + SNP, features=X, decomp=dcmp, terms=3, 
map=MAP[,c(1,3)], distance=2, dcmp_features=ord[1:k])


###################################################
### code chunk number 46: lrgpr.Rnw:484-487
###################################################
# Test SNP x SNP interaction
pv2 = lrgprApply( y ~ sex + SNP*X[,1], features=X, decomp=dcmp, terms=3:5, 
map=MAP[,c(1,3)], distance=2, dcmp_features=ord[1:k], W_til=X[,1])


###################################################
### code chunk number 47: lrgpr.Rnw:495-497
###################################################
options(prompt = "> ")
options(continue = "+ ")


